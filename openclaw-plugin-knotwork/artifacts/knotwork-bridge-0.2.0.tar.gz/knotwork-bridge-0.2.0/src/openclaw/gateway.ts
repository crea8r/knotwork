// gateway.ts — Raw WebSocket RPC to the OpenClaw gateway.
// One connection per call: wait for connect.challenge → send connect → RPC call → close.
// Protocol: server emits connect.challenge event first; client responds with connect RPC
// including token, password, and nonce. Only then can RPC methods be called.

import type { LooseRecord, WsFrame } from '../types'

const OPERATOR_SCOPES = ['operator.read', 'operator.write']

export async function gatewayRpc(
  port: number, token: string | null, password: string | null,
  method: string, params: LooseRecord, timeoutMs = 90_000,
): Promise<unknown> {
  return new Promise((resolve, reject) => {
    const WS = (globalThis as { WebSocket?: typeof WebSocket }).WebSocket
    if (typeof WS !== 'function') { reject(new Error('WebSocket not available in runtime')); return }

    const ws = new WS(`ws://127.0.0.1:${port}/`)
    const reqId = Math.random().toString(36).slice(2, 10)
    let settled = false

    const timer = setTimeout(
      () => done(() => reject(new Error(`gateway '${method}' timed out after ${timeoutMs}ms`))),
      timeoutMs,
    )

    function done(fn: () => void) {
      if (settled) return
      settled = true
      clearTimeout(timer)
      try { ws.close() } catch { /* ignore */ }
      fn()
    }

    function sendRequest() {
      ws.send(JSON.stringify({ type: 'req', id: reqId, method, params }))
    }

    function sendConnect(nonce?: string) {
      const auth: LooseRecord = {}
      if (token) auth.token = token
      if (password) auth.password = password
      if (nonce) auth.nonce = nonce
      const connectParams: LooseRecord = {
        minProtocol: 1,
        maxProtocol: 3,
        client: {
          id: 'gateway-client',
          displayName: 'knotwork-bridge',
          version: '0.2.0',
          platform: typeof process !== 'undefined' ? process.platform : 'linux',
          mode: 'backend',
        },
        role: 'operator',
        scopes: OPERATOR_SCOPES,
        permissions: {},
      }
      if (Object.keys(auth).length) connectParams.auth = auth
      ws.send(JSON.stringify({ type: 'req', id: 'kw-connect', method: 'connect', params: connectParams }))
    }

    const errStr = (e: unknown) =>
      e && typeof e === 'object' ? JSON.stringify(e) : String(e ?? 'unknown')

    // Do NOT send connect on open — wait for connect.challenge event first.
    ws.onopen = () => { /* wait for connect.challenge */ }

    ws.onmessage = (ev: MessageEvent) => {
      let frame: WsFrame
      try { frame = JSON.parse(String(ev.data)) as WsFrame } catch { return }

      // connect.challenge: server demands we prove we have the token before granting scopes.
      if (frame.type === 'event') {
        const f = frame as unknown as { type: string; event?: string; payload?: LooseRecord }
        if (f.event === 'connect.challenge') {
          sendConnect(f.payload?.nonce as string | undefined)
        }
        return
      }

      if (frame.id === 'kw-connect') {
        if (!frame.ok) { done(() => reject(new Error(`gateway connect failed: ${errStr(frame.error)}`))); return }
        sendRequest()
        return
      }
      if (frame.type === 'res' && frame.id === reqId) {
        if (frame.ok) done(() => resolve(frame.payload))
        else done(() => reject(new Error(`gateway '${method}' error: ${errStr(frame.error)}`)))
      }
    }

    ws.onerror = () => done(() => reject(new Error(`WebSocket error calling gateway '${method}'`)))
    ws.onclose = (ev: CloseEvent) => {
      if (!settled && ev.code !== 1000 && ev.code !== 1001) {
        done(() => reject(new Error(`WebSocket closed (${ev.code} ${ev.reason || 'no reason'}) calling '${method}'`)))
      }
    }
  })
}
